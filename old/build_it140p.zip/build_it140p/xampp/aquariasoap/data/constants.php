<?php
// constants.php
// Self-explanatory

$PI = 3.14159265359;
$WATER_DENSITY = 997;
$KELVIN_CELSIUS_RATIO = 273.15;
$HALF_CYLINDER_NAME = "half";
$QUARTER_CYLINDER_NAME = "quarter";
$METER_FOOT_RATIO = 3.281;
$MERALCO_RATE = 10.1830;
