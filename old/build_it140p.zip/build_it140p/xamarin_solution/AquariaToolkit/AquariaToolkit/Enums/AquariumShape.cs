﻿namespace AquariaToolkit
{
    public enum AquariumShape
    {
        Rectangle,
        Bowfront,
        Triangle,
        Pentagon,
        Cylinder,
        HalfCylinder,
        QuarterCylinder
    }
}