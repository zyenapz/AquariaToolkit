﻿namespace AquariaToolkit
{
    public enum FishType
    {
        Angelfish,
        Betta,
        CommonGoldie,
        FancyGoldie,
        Danio,
        Gourami,
        Guppy,
        Molly
    }
}